package bg.softuni.exam.model.enums;

public enum StyleNameEnum {

    POP, ROCK, JAZZ;
}
