package bg.softuni.exam.model.dtos;

public class SongDTO {

    private String performer;
    private String title ;
    private Integer duration;

    public SongDTO(SongDTO song) {
        this.performer = song.getPerformer();
        this.title = song.getTitle();
        this.duration = song.getDuration();
    }

    public String getPerformer() {
        return performer;
    }

    public String getTitle() {
        return title;
    }

    public Integer getDuration() {
        return duration;
    }

}
