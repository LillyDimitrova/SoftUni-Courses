package bg.softuni.exam.web;

import bg.softuni.exam.model.dtos.CreateSongDTO;
import bg.softuni.exam.service.SongService;
import bg.softuni.exam.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class SongController {

    private SongService songService;
    private final UserService userService;

    public SongController(SongService songService, UserService userService) {
        this.songService = songService;
        this.userService = userService;
    }

    @ModelAttribute("createSongDTO")
    public CreateSongDTO initOrder(){
        return new CreateSongDTO();
    }

    @GetMapping("/songs/add")
    public String songs(){
        return "song-add";
    }

    @PostMapping("/songs/add")
    public String orders(@Valid CreateSongDTO createSongDTO, BindingResult bindingResult, RedirectAttributes redirectAttributes) {

        if (!this.userService.isLoggedIn()) {
            return "redirect:/";
        }

        if (bindingResult.hasErrors() || !songService.create(createSongDTO)){
            redirectAttributes.addFlashAttribute("createSongDTO", createSongDTO);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.createSongDTO", bindingResult);

            return "redirect:/songs/add";
        }

        return "redirect:/home";
    }


}
