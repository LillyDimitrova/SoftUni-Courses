package PizzaCalories_04;

public class Main {
    public static void main(String[] args) {

    }
}
